public class data{
    int priority,num;
    public data(int n,int p){
        num=n;
        priority=p;
    }
}